import { z } from 'zod';

export const TravelStyle = z.enum(['budget', 'luxury', 'adventure', 'family', 'solo', 'mid-range']);
export type TravelStyle = z.infer<typeof TravelStyle>;

export const Currency = z.enum(['USD', 'EUR', 'INR', 'GBP']);
export type Currency = z.infer<typeof Currency>;

export const Preference = z.enum([
  'nature', 'temples', 'beaches', 'food', 'nightlife', 
  'adventure', 'shopping', 'history', 'wellness'
]);
export type Preference = z.infer<typeof Preference>;

export const TripType = z.enum(['weekend', 'family', 'business', 'romantic', 'friends', 'solo', 'holiday']);
export type TripType = z.infer<typeof TripType>;

export const TripFormSchema = z.object({
  startLocation: z.string().min(2, 'Starting location is required'),
  destination: z.string().min(2, 'Destination is required'),
  duration: z.number().min(1, 'Duration must be at least 1 day').max(30, 'Max 30 days'),
  budget: z.number().min(1, 'Budget must be at least 1'),
  currency: Currency,
  travelStyle: TravelStyle,
  tripTypes: z.array(TripType).min(1, 'Select at least one trip type'),
  guests: z.number().min(1, 'At least 1 person'),
  preferences: z.array(Preference).min(1, 'Select at least one preference'),
  notes: z.string().optional(),
});

export type TripFormData = z.infer<typeof TripFormSchema>;

export interface MapMarker {
  id: string;
  name: string;
  description: string;
  lat: number;
  lng: number;
  day?: number;
}

export interface SavedTrip {
  id: string;
  userId: string;
  title: string;
  destination: string;
  content: string;
  markers: string; // JSON string
  createdAt: any;
}

export interface DestinationReview {
  id: string;
  destination: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  rating: number;
  review: string;
  videoUrl?: string;
  createdAt: any;
}
