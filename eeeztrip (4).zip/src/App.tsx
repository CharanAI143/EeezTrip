/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { TripForm } from './components/TripForm';
import { ItineraryDisplay } from './components/ItineraryDisplay';
import { type TripFormData } from './types';
import { createTripPlanStream, getVoiceSummary, getAlternativeDestinations } from './lib/gemini';
import { voiceAssistant } from './lib/voice';
import { Sun, Compass, Sparkles, AlertCircle, Bookmark, History, Plus, LogOut, User as UserIcon, Coins, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { auth, googleProvider, signInWithPopup, signOut } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { SavedTrips } from './components/SavedTrips';
import { ReviewDestinations } from './components/ReviewDestinations';
import { ChatBot } from './components/ChatBot';
import { SeasonalTrips } from './components/SeasonalTrips';

import { MoodSelection } from './components/MoodSelection';

type View = 'plan' | 'savings' | 'reviews' | 'mood';

export default function App() {
  const [view, setView] = useState<View>('plan');
  const [user, setUser] = useState<User | null>(null);
  const [itinerary, setItinerary] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [alternatives, setAlternatives] = useState<any[]>([]);
  const [lastSearch, setLastSearch] = useState<TripFormData | null>(null);
  
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Login failed", err);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const handlePlanTrip = async (data: TripFormData) => {
    setView('plan');
    setIsLoading(true);
    setIsComplete(false);
    setError(null);
    setAlternatives([]);
    setItinerary('');
    setLastSearch(data);

    try {
      // Parallelize: check alternatives while streaming itinerary (or wait if you prefer)
      getAlternativeDestinations(data.destination, data.budget, data.currency).then(alts => {
        setAlternatives(alts);
      });

      const fullText = await createTripPlanStream(data, (text) => {
        setItinerary(text);
      });
      setIsComplete(true);
      const summary = await getVoiceSummary(fullText);
      voiceAssistant.speak(summary);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('429')) {
        setError("Whoa! You're planning too fast! Please wait a moment before trying again.");
      } else if (err.message?.includes('402')) {
        setError("We've hit our travel budget for now. Please contact support.");
      } else {
        setError("Something went wrong on our end. Please try again in a bit.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-brand-sand">
      {/* Navigation */}
      <nav className="h-16 px-8 flex items-center justify-between border-b border-brand-border bg-white flex-shrink-0 z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('plan')}>
          <div className="w-8 h-8 bg-gradient-to-br from-brand-coral to-brand-amber rounded-lg shadow-sm flex items-center justify-center">
            <Compass className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight text-brand-slate">EeezTrip</span>
        </div>
        
        <div className="flex gap-4 md:gap-8 items-center text-sm font-medium">
          <button 
            onClick={() => setView('mood')}
            className={`flex items-center gap-2 transition-colors ${view === 'mood' ? 'text-brand-coral' : 'text-gray-500 hover:text-brand-coral'}`}
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Mood Trip</span>
          </button>
          
          <button 
            onClick={() => setView('reviews')}
            className={`flex items-center gap-2 transition-colors ${view === 'reviews' ? 'text-brand-coral' : 'text-gray-500 hover:text-brand-coral'}`}
          >
            <History className="w-4 h-4" />
            <span className="hidden sm:inline">Review Destination</span>
          </button>
          
          <button 
            onClick={() => setView('savings')}
            className={`flex items-center gap-2 transition-colors ${view === 'savings' ? 'text-brand-coral' : 'text-gray-500 hover:text-brand-coral'}`}
          >
            <Bookmark className="w-4 h-4" />
            <span className="hidden sm:inline">My Savings</span>
          </button>

          <div className="h-6 w-px bg-gray-200 mx-2" />

          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 pr-3 border-r border-gray-100">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-brand-border" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-brand-sand border border-brand-border flex items-center justify-center">
                    <UserIcon className="w-4 h-4 text-gray-400" />
                  </div>
                )}
                <span className="text-brand-slate hidden lg:inline max-w-[100px] truncate">{user.displayName?.split(' ')[0]}</span>
              </div>
              <button 
                onClick={handleLogout}
                className="p-2 text-gray-400 hover:text-brand-coral transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="px-5 py-2 bg-brand-navy text-white rounded-full text-sm font-semibold hover:bg-brand-slate transition-all shadow-md active:scale-95"
            >
              Sign In
            </button>
          )}
        </div>
      </nav>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto custom-scrollbar bg-brand-sand relative">
          <AnimatePresence mode="wait">
            {view === 'plan' && (
              <motion.div 
                key="plan"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex flex-col md:flex-row h-full"
              >
                {/* Sidebar Form */}
                <aside className="w-full md:w-[380px] border-r border-brand-border bg-white p-6 overflow-y-auto custom-scrollbar flex flex-col flex-shrink-0">
                  <div className="mb-6">
                    <h1 className="text-3xl font-extrabold text-brand-slate leading-tight mb-2">
                      Plan smarter trips <span className="text-brand-coral text-transparent bg-clip-text bg-gradient-to-r from-brand-coral to-brand-orange">in seconds.</span>
                    </h1>
                    <p className="text-gray-500 text-sm">Fill in your details and let AI craft your perfect escape.</p>
                  </div>
                  
                  <div className="flex-1">
                    <TripForm onSubmit={handlePlanTrip} isLoading={isLoading} />
                  </div>
                </aside>

                <div className="flex-1 p-8 overflow-y-auto">
                  <div className="max-w-4xl mx-auto">
                    {/* Error Message */}
                    <AnimatePresence>
                      {error && (
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="mb-6 px-6 py-4 rounded-2xl bg-red-50 border border-red-100 flex items-center gap-3 text-red-600 shadow-sm"
                        >
                          <AlertCircle className="w-5 h-5 flex-shrink-0" />
                          <p className="text-sm font-medium">{error}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {!itinerary && !isLoading && (
                      <div className="space-y-12 pb-20">
                        <div className="flex flex-col items-center justify-center text-center space-y-6 py-20 bg-white/50 rounded-[3rem] border border-brand-navy/5">
                          <div className="w-20 h-20 rounded-full bg-brand-coral/10 flex items-center justify-center">
                            <Sparkles className="w-10 h-10 text-brand-coral" />
                          </div>
                          <div className="space-y-2">
                            <h3 className="text-2xl font-black text-brand-navy">Ready for your next adventure?</h3>
                            <p className="max-w-xs mx-auto text-brand-navy/60 font-medium">Fill in the form on the left to generate your custom travel itinerary.</p>
                          </div>
                          <button 
                            onClick={() => setView('mood')}
                            className="group flex items-center gap-3 px-8 py-4 bg-brand-navy text-white rounded-full font-black text-xs uppercase tracking-widest shadow-xl shadow-brand-navy/20 hover:scale-105 transition-all"
                          >
                            Unsure? Plan by Mood
                            <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform">
                               <Sparkles className="w-3.5 h-3.5 text-brand-amber" />
                            </div>
                          </button>
                        </div>

                        <SeasonalTrips 
                          userLocation={lastSearch?.startLocation || "New York"}
                          onSelectDestination={(dest) => {
                            if (lastSearch) {
                              handlePlanTrip({ ...lastSearch, destination: dest });
                            } else {
                              const event = new CustomEvent('prefill-trip', { detail: dest });
                              window.dispatchEvent(event);
                              // Smooth scroll to top for mobile engagement
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }
                          }} 
                        />
                      </div>
                    )}

                    <AnimatePresence>
                      {alternatives.length > 0 && isComplete && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="mb-12 bg-gradient-to-br from-brand-navy to-brand-slate rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl"
                        >
                          <div className="absolute top-0 right-0 w-64 h-64 bg-brand-coral/10 blur-[100px] pointer-events-none" />
                          <div className="relative z-10">
                            <div className="flex items-center gap-3 mb-6">
                              <div className="w-10 h-10 bg-brand-coral rounded-xl flex items-center justify-center shadow-lg shadow-brand-coral/40">
                                <Coins className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-black">Budget-Friendly Alternatives</h3>
                                <p className="text-white/60 text-sm">Similar vibes, but easier on your wallet.</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                              {alternatives.map((alt) => (
                                <button
                                  key={alt.name}
                                  onClick={() => handlePlanTrip({ ...lastSearch!, destination: alt.name })}
                                  className="group bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-2xl p-6 text-left border border-white/10 transition-all hover:scale-[1.02] active:scale-95"
                                >
                                  <h4 className="text-lg font-bold mb-2 group-hover:text-brand-coral transition-colors">{alt.name}</h4>
                                  <p className="text-xs text-white/50 mb-4 line-clamp-2">{alt.reason}</p>
                                  <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/10">
                                    <div className="text-[10px] font-black uppercase tracking-widest text-brand-amber">
                                      Est. {alt.estimatedBudget} {lastSearch?.currency}
                                    </div>
                                    <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0" />
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <div ref={resultsRef}>
                      <ItineraryDisplay 
                        content={itinerary} 
                        isComplete={isComplete} 
                        user={user}
                        onSave={() => setView('savings')}
                        onLogin={handleLogin}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'mood' && (
              <motion.div 
                key="mood"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="h-full p-8 md:p-12 overflow-y-auto"
              >
                <div className="max-w-6xl mx-auto space-y-12">
                  <div className="text-center max-w-2xl mx-auto">
                    <h2 className="text-4xl md:text-6xl font-black text-brand-navy mb-4">
                      How are you <span className="text-brand-coral">feeling</span> today?
                    </h2>
                    <p className="text-lg text-brand-navy/60">
                      Tell us your mood and budget. We'll find the perfect landscape to match your soul – from lush greenery to golden deserts.
                    </p>
                  </div>

                  <MoodSelection 
                    onSelectDestination={(dest, budget, currency) => {
                      // Trigger plan trip with values from MoodSelection + defaults
                      handlePlanTrip({
                        startLocation: "New York", // Default fallback or could be fetched from user location if available
                        destination: dest,
                        duration: 7,
                        budget: budget,
                        currency: currency as any,
                        travelStyle: 'mid-range',
                        tripTypes: ['solo'],
                        guests: 1,
                        preferences: ['nature', 'food'],
                        notes: `Suggest based on mood matching ${dest}`
                      });
                    }} 
                  />
                </div>
              </motion.div>
            )}

            {view === 'savings' && (
              <motion.div 
                key="savings"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full cursor-default"
              >
                <div className="max-w-6xl mx-auto p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h2 className="text-3xl font-bold text-brand-slate">My Savings</h2>
                      <p className="text-gray-500">Your collection of planned adventures.</p>
                    </div>
                    <button 
                      onClick={() => setView('plan')}
                      className="flex items-center gap-2 px-6 py-3 bg-brand-navy text-white rounded-full font-bold shadow-lg hover:bg-brand-slate transition-all active:scale-95"
                    >
                      <Plus className="w-5 h-5" />
                      Plan New Trip
                    </button>
                  </div>
                  
                  <SavedTrips user={user} onLogin={handleLogin} />
                </div>
              </motion.div>
            )}

            {view === 'reviews' && (
              <motion.div 
                key="reviews"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full"
              >
                <div className="max-w-5xl mx-auto p-8">
                  <div className="mb-8">
                    <h2 className="text-3xl font-bold text-brand-slate">Review Destination</h2>
                    <p className="text-gray-500">Share your review through videos and text prompt named with your signed account name.</p>
                  </div>
                  
                  <ReviewDestinations user={user} onLogin={handleLogin} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Footer */}
      <footer className="h-12 px-8 flex items-center border-t border-brand-border bg-white text-xs text-gray-400 flex-shrink-0">
        <div className="flex-1">© 2026 EeezTrip - Smart Travel Made Easy</div>
        <div className="flex gap-4">
          <span className="hover:text-brand-coral cursor-pointer">Explore</span>
          <span className="hover:text-brand-coral cursor-pointer">Privacy</span>
          <span className="hover:text-brand-coral cursor-pointer">Terms</span>
        </div>
      </footer>
      <ChatBot />
    </div>
  );
}

