import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import cors from "cors";
import dotenv from "dotenv";

import fs from "fs/promises";

dotenv.config();

const CACHE_FILE = path.join(process.cwd(), "data", "image_cache.json");

async function loadCache() {
  try {
    const data = await fs.readFile(CACHE_FILE, "utf-8");
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveCache(cache: any) {
  try {
    await fs.mkdir(path.dirname(CACHE_FILE), { recursive: true });
    await fs.writeFile(CACHE_FILE, JSON.stringify(cache, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving cache:", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // --- Image Fetcher Logic ---
  const WIKIMEDIA_API = "https://commons.wikimedia.org/w/api.php";

  app.get("/api/images", async (req, res) => {
    const { place, state, tags } = req.query;
    const placeName = place as string;
    const stateName = state as string || "";
    const tagsList = tags ? (tags as string).split(",") : [];

    if (!placeName) {
      return res.status(400).json({ error: "Missing place name" });
    }

    const cacheKey = `${placeName.toLowerCase()}|${stateName.toLowerCase()}`;
    const cache = await loadCache();

    if (cache[cacheKey]) {
      return res.json(cache[cacheKey]);
    }

    try {
      let images: any[] = [];

      // 1. Wikimedia (Primary)
      try {
        const response = await axios.get(WIKIMEDIA_API, {
          params: {
            action: "query",
            generator: "search",
            gsrsearch: `intitle:${placeName} landscape scenic`,
            gsrnamespace: "6",
            gsrlimit: 15,
            prop: "imageinfo",
            iiprop: "url|dimensions|user",
            iiurlwidth: 1280,
            format: "json",
            origin: "*",
          },
          headers: {
            "User-Agent": "TripSync/1.0 (contact@example.com)",
          },
        });

        const pages = response.data.query?.pages || {};
        const wikiImages = Object.values(pages)
          .map((page: any) => {
            const info = page.imageinfo?.[0];
            if (!info) return null;
            
            const title = page.title.replace("File:", "");
            const validExts = [".jpg", ".jpeg", ".png", ".webp"];
            if (!validExts.some(ext => title.toLowerCase().endsWith(ext))) return null;

            return {
              image_id: `commons-${page.pageid}`,
              url: info.url,
              alt: title,
              author: info.user || "Unknown",
              source: "wikimedia",
            };
          })
          .filter(Boolean);

        images = wikiImages.slice(0, 5);
      } catch (error) {
        console.error("Wikimedia error:", error);
      }

      // 2. Final Fallback (Generic)
      if (images.length === 0) {
        images = [{
          image_id: "generic-fallback",
          url: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1000&auto=format&fit=crop",
          alt: "Beautiful Travel Destination",
          author: "Unsplash",
          source: "fallback"
        }];
      }

      if (images.length > 0) {
        cache[cacheKey] = images;
        await saveCache(cache);
      }

      res.json(images);
    } catch (error) {
      console.error("Image fetcher global error:", error);
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
